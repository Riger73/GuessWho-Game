# AlgorithmsA2-GuessWho

## Compiling
 Compile and run with `make`
 current set up will create two random players edit makefile to change this